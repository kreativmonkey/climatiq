"""Test suite for HVAC Optimizer."""
