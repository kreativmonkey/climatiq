"""Unit tests for HVAC Optimizer."""
