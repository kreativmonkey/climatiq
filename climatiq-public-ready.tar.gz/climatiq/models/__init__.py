"""Machine learning models for cycling prediction."""
