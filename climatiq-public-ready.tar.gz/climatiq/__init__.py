"""HVAC Optimizer - Intelligent heat pump control to prevent short-cycling."""

__version__ = "0.1.0"
