"""AppDaemon integration for HVAC Optimizer."""
