"""Analysis modules for HVAC data."""
